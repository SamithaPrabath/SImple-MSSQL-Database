-- *** Views ***
USE awasdb;
-- Returns Exporter Exporter Requests that have not yet been assigned or completed.

GO

create view Available_Exporter_Requests
as
select * from Exporter_Request where
Exporter_Request.Exporter_Request_ID not in (select Exporter_Request_ID from Completed_Exporter_Request)
and Exporter_Request.Exporter_Request_ID not in (select Exporter_Request_ID from Task);

GO

-- Returns Attendances which have not yet been signed-off.

create view Available_Attendances
as
select * from Attendance where 
Attendance.Attendance_ID not in (select Attendance_ID from Attendance_Sign_Off);

GO

-- Returns the Number of Tasks assigned to each available attendance

create view Assigned_Task_Number_Attendace AS
select Available_Attendances.Attendance_ID, sum(case when Task.Exporter_Request_ID is not null then 1 else 0 end) as 'Task_Number' from Task
right join Available_Attendances on Task.Attendance_ID = Available_Attendances.Attendance_ID
group by Available_Attendances.Attendance_ID;


