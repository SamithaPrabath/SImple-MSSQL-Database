-- ** Procedures **
USE awasdb;

GO

-- Marks Attendance for an Officer
create proc markAttendance
	@AttendanceID int,
	@OfficerID int,
	@AttendanceDate datetime
AS
insert into Attendance values (@AttendanceID, @OfficerID, @AttendanceDate);

GO

-- Make an Exporter Request
create proc makeExporterRequest
	@ExporterRequestID int,
	@ExporterID int,
	@Exporter_Request_Desc varchar(100),
	@Exporter_Request_Date_Time datetime
AS
insert into Exporter_Request values (@ExporterRequestID, @ExporterID, @Exporter_Request_Desc, @Exporter_Request_Date_Time);

GO

-- Sign-off an Attendance
create proc signOffAttendance
	@AttendanceID int,
	@Sign_Off_Date_Time datetime
AS
insert into Attendance_Sign_Off values (@AttendanceID, @Sign_Off_Date_Time);

GO

-- Complete Exporter Request
create proc completeExporterRequest
	@ExporterRequestID int,
	@Completed_Date_Time datetime
AS
declare @AttendanceID int;
select @AttendanceID = Attendance_ID from Task where Exporter_Request_ID = @ExporterRequestID;
if @AttendanceID is not null
	begin
		insert into Completed_Exporter_Request values (@ExporterRequestID, @AttendanceID, @Completed_Date_Time);
	end;


