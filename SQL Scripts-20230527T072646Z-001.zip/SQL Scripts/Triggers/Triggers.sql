-- *** Triggers *** 

GO

-- Trigger to allocate tasks upon an attendance marking
create trigger AllocateOnAttendance ON Attendance
AFTER INSERT
AS
declare @ExporterRequestID int, @Attendance_ID int;
select top(1) @Attendance_ID = Attendance_ID from inserted;
declare AvailableERBatch cursor for
	select top(5) Exporter_Request_ID from Available_Exporter_Requests order by Exporter_Request_Date_Time; 
open AvailableERBatch;
fetch next from AvailableERBatch into @ExporterRequestID;
while @@FETCH_STATUS <> -1
	begin
		insert into Task values (@ExporterRequestID, @Attendance_ID);
		fetch next from AvailableERBatch into @ExporterRequestID;
	end;
close AvailableERBatch;
deallocate AvailableERBatch;

GO

-- Trigger to allocate tasks upon the making of an exporter request
create trigger AllocateOnExporterRequest ON Exporter_Request
AFTER INSERT
AS
declare @ExporterRequestID int, @AttendanceID int;
select top(1) @ExporterRequestID = Exporter_Request_ID from inserted;
select top(1) @AttendanceID = Attendance_ID from Assigned_Task_Number_Attendace 
where Task_Number = (
	select min(Task_Number) from Assigned_Task_Number_Attendace
);
if @AttendanceID is not null
	insert into task values (@ExporterRequestID, @AttendanceID);


GO

-- Trigger to complete a given task
create trigger CompleteTask ON Completed_Exporter_Request
AFTER INSERT
AS
declare @ExporterRequestID int, @AttendanceID int, @ExporterRequestIDNew int;;
select top(1) @ExporterRequestID = Exporter_Request_ID from inserted;
select @AttendanceID = Attendance_ID from Task where Exporter_Request_ID = @ExporterRequestID;
if @AttendanceID is not null
begin
	DELETE from Task where Exporter_Request_ID = @ExporterRequestID;
	select top(1) @ExporterRequestIDNew = Exporter_Request_ID from Available_Exporter_Requests order by Exporter_Request_Date_Time asc;
	if @ExporterRequestIDNew is not null
		begin
			insert into Task values (@ExporterRequestIDNew, @AttendanceID);
		end;
end;


GO

-- Trigger to deallocate tasks upon an attendance sign off
create trigger SignOff ON Attendance_Sign_Off
AFTER INSERT
AS
declare @AttendanceID int;
select top(1) @AttendanceID = Attendance_ID from inserted;
delete from Task where Attendance_ID = @AttendanceID;

GO
